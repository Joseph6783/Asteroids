"""
File: asteroids.py
Original Author: Br. Burton
Designed to be completed by others
This program implements the asteroids game.

Completed by Joseph Stone
CS241 with Brother Manly
"""
import arcade
import math
import random
from abc import ABC
from abc import abstractmethod

# These are Global constants to use throughout the game
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

BULLET_RADIUS = 30
BULLET_SPEED = 10
BULLET_LIFE = 60

SHIP_TURN_AMOUNT = 3
SHIP_THRUST_AMOUNT = 0.25

#radius of 30 is too small for accurate check_collison method 
SHIP_RADIUS = 45

INITIAL_ROCK_COUNT = 5

BIG_ROCK_SPIN = 1
BIG_ROCK_SPEED = 1.5
BIG_ROCK_RADIUS = 15

MEDIUM_ROCK_SPIN = -2
MEDIUM_ROCK_RADIUS = 5

SMALL_ROCK_SPIN = 5
SMALL_ROCK_RADIUS = 2
TEXTURE_SHIP = arcade.load_texture("ship.png")
TEXTURE_BULLET = arcade.load_texture("laser.png")
TEXTURE_LARGE = arcade.load_texture("big.png")
TEXTURE_MEDIUM = arcade.load_texture("medium.png")
TEXTURE_SMALL = arcade.load_texture("small.png")
TEXTURE_EXPLOSION = arcade.load_texture("explosion.png")

class Point:
    """
    Creates a point class with x and y attributes.
    """
    def __init__ (self):
        """
        Initializes a point at (0,0).
        """
        self.x = 0
        self.y = 0

class Velocity:
    """
    Creates a velocity class with x and y direction attributes.
    """
    def __init__(self):
        """
        Initializes velocity to 0.
        """
        self.dx = 0
        self.dy = 0
        
class Flying_Object(ABC):
    """
    Makes and controls the base class flying object
    """
    def __init__(self):
        """
        Initializes a flying object with it's necessary attributes.
        """
        self.center = Point()
        self.velocity = Velocity()
        self.radius = BIG_ROCK_RADIUS
        self.alive = True
        self._angle = 0
        
    @property
    def angle(self):
        """
        Property to make the angle attribute protected.
        """
        return self._angle
    
    @angle.setter
    def angle(self, angle):
        """
        Sets the angle to the desired values.
        """
        if angle > 360:
            self._angle = 0
            
        elif angle < 0:
            self._angle = 359
        
        else:
            self._angle = angle
            
    #polymorphism 
    @abstractmethod
    def draw(self):
        """
        abastract draw method
        """
        pass
    
    def advance(self):
        """
        Controls how the flying object moves on the screen.
        """
        self.center.x += self.velocity.dx
        self.center.y += self.velocity.dy

        if self.center.y <= 0:
            self.center.y = SCREEN_HEIGHT
        
        elif self.center.x <= 0:
            self.center.x = SCREEN_WIDTH
        
        elif self.center.y > SCREEN_HEIGHT:
            self.center.y = 0
        
        elif self.center.x > SCREEN_WIDTH:
            self.center.x = 0

            
class Asteroid(Flying_Object):
    """
    Large Asteroid that breaks into two medium and one small asteroids 
    """
    def __init__(self):
        """
        Initializes the Asteroid with the proper attributes.
        """
        super().__init__()
        self.center.y = random.uniform(0, SCREEN_HEIGHT)
        self.center.x = random.uniform(0, SCREEN_WIDTH * -1)
        self.velocity.dx = random.uniform(-BIG_ROCK_SPEED, BIG_ROCK_SPEED)   
        self.velocity.dy = random.uniform(-BIG_ROCK_SPEED, BIG_ROCK_SPEED)
        
    def advance(self):
        """
        Controls how the Asteroid moves on the screen.
        """
        super().advance()
        self.angle += BIG_ROCK_SPIN
        
    def draw(self):
        """
        Sets how the asteroid is to be drawn on the screen.
        """
        arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_LARGE.width, TEXTURE_LARGE.height, TEXTURE_LARGE, self.angle)   
    
    def hit(self):
        """
        Breaks the asteroid when hit.
        """
        self.alive = False
        return [Medium_Asteroid(self), Medium_Asteroid(self), Small_Asteroid(self)]
        
class Medium_Asteroid(Flying_Object):
    """
    Medium asteroid that when hit breaks into two small asteroids
    """
    def __init__(self, large):
        """
        Initializes the Asteroid with the proper attributes.
        """
        super().__init__()
        self.radius = MEDIUM_ROCK_RADIUS
        self.center.x = large.center.x
        self.center.y = large.center.y
        self.velocity.dx = random.uniform(1, 3)    
        self.velocity.dy = random.uniform(-2, 3)
        
    def advance(self):
        """
        Controls how the Asteroid moves on the screen.
        """
        super().advance()
        self.angle += MEDIUM_ROCK_SPIN
        
    def draw(self):
        """
        Sets how the asteroid is to be drawn on the screen.
        """
        arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_MEDIUM.width, TEXTURE_MEDIUM.height, TEXTURE_MEDIUM, self.angle)    
    
    def hit(self):
        """
        Breaks the asteroid when hit.
        """
        self.alive = False
        return [Small_Asteroid(self), Small_Asteroid(self)]
    
class Small_Asteroid(Flying_Object):
    """
    Small asteroid that dies when hit once
    """
    def __init__(self, large):
        """
        Initializes the Asteroid with the proper attributes.
        """
        super().__init__()
        self.radius = SMALL_ROCK_RADIUS
        self.center.x = large.center.x
        self.center.y = large.center.y
        self.velocity.dx = random.uniform(1, 5)    
        self.velocity.dy = random.uniform(-2, 3)
        
    def advance(self):
        """
        Controls how the Asteroid moves on the screen.
        """
        super().advance()
        self.angle += SMALL_ROCK_SPIN
        
    def draw(self):
        """
        Sets how the asteroid is to be drawn on the screen.
        """
        arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_SMALL.width, TEXTURE_SMALL.height, TEXTURE_SMALL, self.angle)    
    
    def hit(self):
        """
        Breaks the asteroid when hit.
        """
        self.alive = False
        return ()

class Ship(Flying_Object):
    """
    The ship appears on the screen and can be moved by the user.
    """
    def __init__(self):
        """
        Initializes the Ship with the proper attributes.
        """
        super().__init__()
        self.center = Point()
        self.radius = SHIP_RADIUS
        self.center.x = SCREEN_WIDTH / 2
        self.center.y = SCREEN_HEIGHT / 2

    def increase_velocity(self):
        """
        Increases the velocity in the direction the ship is facing.
        """
        self.velocity.dx -= math.sin(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        self.velocity.dy += math.cos(math.radians(self.angle)) * SHIP_THRUST_AMOUNT

    def decrease_velocity(self):
        """
        Decreases the velocity in the direction the ship is facing to negative velocity.
        """
        self.velocity.dx += math.sin(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        self.velocity.dy -= math.cos(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        
    def advance(self):
        """
        Controls how the ship moves on the screen.
        """
        if self.alive:
            self.center.x += self.velocity.dx
            self.center.y += self.velocity.dy

            if self.center.y <= 0:
                self.center.y = SCREEN_HEIGHT
        
            elif self.center.x <= 0:
                self.center.x = SCREEN_WIDTH
        
            elif self.center.y > SCREEN_HEIGHT:
                self.center.y = 0
        
            elif self.center.x > SCREEN_WIDTH:
                self.center.x = 0

        else:
            pass
        
    def draw(self):
        """
        Sets how the ship is to be drawn on the screen.
        """
        if self.alive:
            arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_SHIP.width, TEXTURE_SHIP.height, TEXTURE_SHIP, self.angle)
        else:
            arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_EXPLOSION.width / 2, TEXTURE_EXPLOSION.height / 2, TEXTURE_EXPLOSION)
        
class Bullet(Flying_Object):
    """
    The bullet is a laser that flies from the ship.
    """
    def __init__(self, ship):
        """
        Initializes the Bullet with the proper attributes.
        """
        super().__init__()
        self.center.x = ship.center.x
        self.center.y = ship.center.y
        self.velocity.dx = ship.velocity.dx
        self.velocity.dy = ship.velocity.dy
        self.radius = BULLET_RADIUS
        self.bullet_life = 0
        self.angle = ship.angle
        
    def advance(self, ship):
        """
        Controls how the bullet moves on the screen.
        """
        super().advance()
        self.bullet_life += 1
        if self.bullet_life <= BULLET_LIFE:
            self.center.x += self.velocity.dx
            self.center.y += self.velocity.dy
        else:
            self.alive = False
            
            
    def draw(self, ship):
        """
        Sets how the bullet is to be drawn on the screen.
        """
        arcade.draw_texture_rectangle(self.center.x, self.center.y, TEXTURE_BULLET.width, TEXTURE_BULLET.height, TEXTURE_BULLET, self.angle + 90)

    def fire(self, ship):
        """
        Fires the bullets at the desired velocity and direction from the ship
        """
        self.velocity.dy += math.cos(math.radians(ship.angle)) * BULLET_SPEED
        self.velocity.dx -= math.sin(math.radians(ship.angle)) * BULLET_SPEED

      
class Text:
    """
    This class makes all written messages
    """
    def __init__(self):
        """
        Assigns the proper text and attribute to the different messages.
        """
        self.time = 0
        self.welcome_text = "Welcome to Asteroids!\nControls:\nArrow keys to move\nSpace to shoot"
        self.congrats = "YOU WON!!\n\nPress r to play again"
        self.game_over = "Game Over!\n\nPress r to restart"
        self.start_x = 260
        self.start_y = SCREEN_HEIGHT * (2/3)
        
    def draw_won_game(self):
        """
        draws on the screen if all the asteroids are destroyed
        """
        arcade.draw_text(self.congrats, start_x=self.start_x, start_y=self.start_y, font_size = 30, color=arcade.color.WHITE)
        
    def draw_lost_game(self):
        """
        draws on the screen when the ship dies.
        """
        arcade.draw_text(self.game_over, start_x=self.start_x, start_y=self.start_y, font_size = 30, color=arcade.color.WHITE)
        
    def draw_welcome(self):
        """
        draws initial instructions.
        """
        if self.time <= 150:
            arcade.draw_text(self.welcome_text, start_x=self.start_x, start_y=self.start_y, font_size = 30, color=arcade.color.WHITE)
            self.time += 1
        else:
            pass

class Game(arcade.Window):
    """
    This class handles all the game callbacks and interaction
    This class will then call the appropriate functions of
    each of the above classes.
    You are welcome to modify anything in this class.
    """
    def __init__(self, width, height):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        """
        super().__init__(width, height)
        arcade.set_background_color(arcade.color.SMOKY_BLACK)

        self.held_keys = set()
        self.restart()
        
            
    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()
        
        self.text.draw_welcome()
        
        self.ship.draw()

        for bullet in self.bullets:
            bullet.draw(self.ship)

        for asteroid in self.asteroids:
            asteroid.draw()
            
        if len(self.asteroids) == 0 and self.ship.alive:
            self.text.draw_won_game()
            
        elif self.ship.alive == False:
            self.text.draw_lost_game() 

        
    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """
        self.check_keys()
        
        for bullet in self.bullets:
            bullet.advance(self.ship)

        for asteroid in self.asteroids:
            asteroid.advance()
            
        self.ship.advance()

        self.check_collisions()
         
    def check_collisions(self):
        """
        Checks to see if bullets have hit asteroids.
        Kills the objects that collide and removes dead items.
        :return:
        """
        for bullet in self.bullets:
            for asteroid in self.asteroids:

                # Make sure they are both alive before checking for a collision
                if bullet.alive and asteroid.alive:
                    too_close = bullet.radius + asteroid.radius

                    if (abs(bullet.center.x - asteroid.center.x) < too_close and
                                abs(bullet.center.y - asteroid.center.y) < too_close):
                        # its a hit!
                        bullet.alive = False
                        self.asteroids.extend(asteroid.hit())
                        
        for asteroid in self.asteroids:

            # Make sure they are both alive before checking for a collision
            if asteroid.alive and self.ship.alive:
                too_close = asteroid.radius + self.ship.radius

                if (abs(asteroid.center.x - self.ship.center.x) < too_close and
                            abs(asteroid.center.y - self.ship.center.y) < too_close):
                    # its a hit!
                    self.ship.alive = False
                    asteroid.hit()
                    

                        # We will wait to remove the dead objects until after we
                        # finish going through the list

        # Now, check for anything that is dead, and remove it
        self.cleanup_zombies()

    def cleanup_zombies(self):
        """
        Removes any dead bullets or asteroids from the list.
        :return:
        """
        for bullet in self.bullets:
            if not bullet.alive:
                self.bullets.remove(bullet)

        for asteroid in self.asteroids:
            if not asteroid.alive:
                self.asteroids.remove(asteroid)


    def check_keys(self):
        """
        This function checks for keys that are being held down.
        """
        if arcade.key.LEFT in self.held_keys:
            self.ship.angle += SHIP_TURN_AMOUNT

        if arcade.key.RIGHT in self.held_keys:
            self.ship.angle -= SHIP_TURN_AMOUNT

        if arcade.key.UP in self.held_keys:
            self.ship.increase_velocity()

        if arcade.key.DOWN in self.held_keys:
            self.ship.decrease_velocity()

    def on_key_press(self, key: int, modifiers: int):
        """
        Puts the current key in the set of keys that are being held.
        """
        if self.ship.alive:
            self.held_keys.add(key)

            if key == arcade.key.SPACE:
                bullet = Bullet(self.ship)
                bullet.fire(self.ship)
                
                self.bullets.append(bullet)
                
        if key == arcade.key.R:
            self.restart()
            

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            self.held_keys.remove(key)
            
    def restart(self):
        """
        Initializes the objects needed to play the game.
        """
        self.ship = Ship()
        self.large = Asteroid()
        self.medium = Medium_Asteroid(self.large)
        self.small = Small_Asteroid(self.large)
        self.text = Text()
        
        self.bullets = []
        
        self.asteroids = [Asteroid(), Asteroid(), Asteroid(), Asteroid(), Asteroid()]

# Creates the game and starts it going
window = Game(SCREEN_WIDTH, SCREEN_HEIGHT)
arcade.run()